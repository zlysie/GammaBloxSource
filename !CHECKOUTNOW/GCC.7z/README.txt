GCCService should be patched correctly to have security patches but check just incase.
ALSO UPDATE THE CONFIG FILE!